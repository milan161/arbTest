# -*- coding: utf-8 -*-
# etf_01_data_init.py - ETF 轮动套利数据初始化与日更程序
# 核心职责：读取 ETFList.csv，通过 arbcore 获取最新净值与收盘价，存入统一大数据库。

import os
import sys
import pandas as pd
import logging

from core.db_manager import DatabaseManager

logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def clean_fund_code(series: pd.Series) -> list:
    """辅助函数：安全地清洗和格式化基金代码，确保为 6 位数字字符串"""
    return (
        series.dropna()
        .astype(str)
        .str.strip()
        # 使用正则仅匹配并移除结尾的 .0，防止误伤
        .str.replace(r'\.0+$', '', regex=True)
        .str.zfill(6)
        .tolist()
    )

def init_etf_data():
    """初始化并更新 ETF 基础数据"""
    
    logger.info("=== 启动 ETF 轮动数据初始化 (基于 arbcore 新架构) ===")
    
    # 1. 实例化核心数据库管理器
    db = DatabaseManager()
    
    # 2. 读取配置池 (使用 CSV 作为人类友好的配置入口)
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(BASE_DIR, 'ETFList.csv')
    if not os.path.exists(csv_path):
        logger.error(f"❌ 找不到 ETF 列表文件: {csv_path}，请确保该文件存在！")
        return
        
    # 优雅的文件读取容错处理
    df_list = None
    try:
        df_list = pd.read_csv(csv_path, encoding='utf-8-sig')
    except UnicodeDecodeError:
        try:
            df_list = pd.read_csv(csv_path, encoding='gbk')
            logger.info("⚠️ 使用 gbk 编码成功读取 CSV 文件。")
        except Exception as e:
            logger.error(f"❌ 使用 gbk 编码读取 CSV 文件也失败了，错误信息: {e}")
            return
    except Exception as e:
        logger.error(f"❌ 读取 CSV 文件发生未知异常: {e}")
        return
        
    # 核心修复：彻底清洗 BOM 隐藏字符和两端空格，绝对防止入库失败
    df_list.columns = df_list.columns.str.strip().str.replace('\ufeff', '')
    
    # 核心校验前置：确保必需的两列都存在
    required_columns = ['ETF基金代码', 'LOF基金代码']
    missing_cols = [col for col in required_columns if col not in df_list.columns]
    if missing_cols:
        logger.error(f"❌ CSV 文件中缺失核心列 {missing_cols}，当前识别到的列有: {df_list.columns.tolist()}")
        return
        
    # 核心修复：剔除任何无用的空行，防止 Excel 空白行产生的 NaN 导致数据库入库崩溃
    df_list = df_list.dropna(subset=required_columns)
        
    # 将 CSV 配置全量同步到主数据库中
    try:
        db.sync_etf_rotation_list(df_list)
        logger.info("✅ 成功将 ETF 配置数据同步至主数据库。")
    except Exception as e:
        logger.error(f"❌ 同步数据至数据库失败: {e}")
        return
        
    # 提取代码并格式化，合并 LOF 与 ETF 组成全局池一起获取数据 (复用通用清洗逻辑)
    lof_codes = clean_fund_code(df_list['LOF基金代码'])
    etf_codes = clean_fund_code(df_list['ETF基金代码'])
    all_codes = list(set(lof_codes + etf_codes))
    
    logger.info(f"✅ 成功加载监控池，包含去重后的 LOF 与 ETF 标的共 {len(all_codes)} 只。")
    logger.info("=== ETF 轮动数据初始化执行完毕！请检查数据库。 ===")

if __name__ == "__main__":
    init_etf_data()
    
    
    