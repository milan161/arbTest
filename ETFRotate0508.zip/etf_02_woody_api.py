# -*- coding: utf-8 -*-
# etf_02_woody_api.py - ETF 轮动套利专属的 Woody API 因子提取程序

import os
import sys
import pandas as pd
import logging
from contextlib import closing

from core.db_manager import DatabaseManager
from core.woody_api_service import WoodyAPIService

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def main():
    logger.info("=== 启动 ETF 轮动专属 Woody API 因子获取程序 ===")
    db = DatabaseManager()
    
    # 1. 安全管理数据库连接：无论是否发生异常，确保连接被释放
    try:
        with closing(db._get_conn()) as conn:
            df_list = pd.read_sql("SELECT lof_code, etf_code FROM etf_rotation_list", conn)
    except Exception as e:
        logger.error(f"❌ 数据库查询失败，请检查 etf_rotation_list 表状态: {e}")
        return
    
    if df_list.empty:
        logger.error("⚠️ ETF 轮动配置表为空，请先运行 etf_01_data_init.py 同步配置！")
        return
        
    # 2. 健壮的数据清洗：合并两列 -> 剔除 NaN -> 转为字符串 -> 去除首尾空格 -> 过滤纯空字符 -> 去重
    codes_series = pd.concat([df_list['lof_code'], df_list['etf_code']])
    valid_codes = codes_series.dropna().astype(str).str.strip()
    valid_codes = list(set(valid_codes[valid_codes != '']))
    
    if not valid_codes:
        logger.error("⚠️ 未在数据库中提取到有效的基金代码，请检查配置！")
        return

    # 3. 防御性文件系统操作：确保备份目录物理存在
    backup_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'woodyAPI')
    os.makedirs(backup_dir, exist_ok=True)
    
    logger.info(f"📊 准备提取 {len(valid_codes)} 只基金的 Woody 因子...")
    
    # 4. 隔离外部服务调用的风险
    try:
        WoodyAPIService.fetch_and_process(db, valid_codes, backup_dir, source_id='woody_etf')
        logger.info("=== ✅ ETF 轮动 Woody API 获取任务结束 ===")
    except Exception as e:
        logger.error(f"❌ Woody API 因子获取任务发生异常中断: {e}", exc_info=True)

if __name__ == "__main__":
    main()
