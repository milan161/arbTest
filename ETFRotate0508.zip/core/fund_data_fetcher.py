# -*- coding: utf-8 -*-
import time
import json
import logging
import requests
import pandas as pd
from datetime import datetime, timedelta

# 配置日志记录器
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DataFetcher:
    def __init__(self):
        # 初始化通用的请求头，防止被反爬拦截
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json, text/javascript, */*; q=0.01'
        }

    def fetch_lof_nav_data(self, fund_code, existing_data=None):
        """从东财获取LOF基金历史净值数据
        
        Args:
            fund_code: LOF基金代码
            existing_data: 现有的数据，用于检查是否需要爬取
        
        Returns:
            dict: 包含日期和净值的字典
        """
        logger.info(f"从东财获取LOF基金 {fund_code} 历史净值数据")
        
        # 检查是否需要爬取
        if existing_data is not None:
            # 检查是否有最新数据
            today = datetime.now().date().strftime('%Y-%m-%d')
            if not existing_data.empty:
                latest_date = existing_data['日期'].max()
                if latest_date == today:
                    logger.info(f"已有最新数据，跳过爬取")
                    # 从现有数据中提取净值字典
                    nav_dict = {}
                    for idx, row in existing_data.iterrows():
                        if pd.notna(row.get('LOF净值')):
                            nav_dict[row['日期']] = row['LOF净值']
                    return nav_dict
        
        # 构建净值字典
        nav_dict = {}
        
        try:
            nav_headers = {'Referer': 'http://fundf10.eastmoney.com/'}
            nav_count = 0
            
            # 只需获取第1页(最近100个交易日)，足够覆盖30天的日更需求
            for page in range(1, 2):
                nav_url = f"http://api.fund.eastmoney.com/f10/lsjz?fundCode={fund_code}&pageIndex={page}&pageSize=100"
                try:
                    nav_response = requests.get(nav_url, headers=nav_headers, timeout=10, verify=False, proxies={"http": None, "https": None})
                    nav_data = nav_response.json()
                    
                    if nav_data.get('Data') and nav_data['Data'].get('LSJZList'):
                        nav_list = nav_data['Data']['LSJZList']
                        if not nav_list:
                            break  # 数据已取完
                            
                        for item in nav_list:
                            date = item.get('FSRQ')
                            nav = item.get('DWJZ')
                            if date and nav:
                                nav_dict[date] = float(nav)
                                nav_count += 1
                    else:
                        break
                except Exception as e:
                    logger.error(f"第 {page} 页获取净值失败: {e}")
                    break
                    
            logger.info(f"成功获取到 {nav_count} 条净值记录！")
        except Exception as e:
            logger.error(f"获取净值数据时出错: {e}")
        
        return nav_dict
    
    def fetch_lof_price_data(self, fund_code, existing_data=None):
        """从新浪获取LOF基金历史收盘价格数据
        
        Args:
            fund_code: LOF基金代码
            existing_data: 现有的数据，用于检查是否需要爬取
        
        Returns:
            DataFrame: 包含LOF基金历史数据的DataFrame
        """
        logger.info(f"从新浪获取LOF基金 {fund_code} 历史收盘价格数据")
        
        # 检查是否需要爬取
        if existing_data is not None:
            # 检查是否有最新数据
            today = datetime.now().date().strftime('%Y-%m-%d')
            if not existing_data.empty:
                latest_date = existing_data['日期'].max()
                if latest_date == today:
                    logger.info(f"已有最新数据，跳过爬取")
                    return existing_data
        
        # 计算日期范围
        end_date = datetime.now().date()
        start_date = (datetime.now() - timedelta(days=30)).date()
        days_to_fetch = (end_date - start_date).days + 1
        days_to_fetch = max(days_to_fetch, 30)
        
        # 根据基金代码前缀确定交易所（50开头为上交所，16开头为深交所）
        exchange_prefix = 'sh' if fund_code.startswith('50') else 'sz'
        exchange_prefix = 'sh' if fund_code.startswith('5') else 'sz'
        sina_url = f"http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol={exchange_prefix}{fund_code}&scale=240&ma=no&datalen={days_to_fetch}"
        logger.info(f"新浪API获取 {days_to_fetch} 天的数据")
        
        # 发送请求，添加重试机制
        max_retries = 3
        retry_count = 0
        
        sina_data = None
        while retry_count < max_retries:
            try:
                response = requests.get(sina_url, headers=self.headers, timeout=15, verify=False, proxies={"http": None, "https": None})
                logger.info(f"新浪API响应状态码: {response.status_code}")
                response.raise_for_status()  # 检查请求是否成功
                
                # 解析响应
                sina_data = response.json()
                break  # 请求成功，退出重试循环
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
                retry_count += 1
                logger.error(f"获取新浪历史数据失败，正在重试 ({retry_count}/{max_retries}): {e}")
                time.sleep(3)  # 等待3秒后重试
            except Exception as e:
                logger.error(f"获取新浪历史数据失败: {e}")
                # 继续重试
                retry_count += 1
                if retry_count < max_retries:
                    logger.info(f"正在重试 ({retry_count}/{max_retries})")
                    time.sleep(3)
                else:
                    # 所有重试失败，无法获取数据
                    logger.error("所有重试失败，无法获取新浪的LOF历史收盘价格数据")
                    # 即使新浪失败，也继续处理，使用现有数据
                    sina_data = []
        
        if isinstance(sina_data, list):
            logger.info(f"找到 {len(sina_data)} 条新浪历史交易记录")
            
            # 解析新浪历史数据
            lof_data = []
            date_set = set()  # 用于跟踪已处理的日期
            
            # 获取今天的日期字符串
            today_str = datetime.now().date().strftime('%Y-%m-%d')
            
            for item in sina_data:
                date = item.get('day')  # 日期
                close = item.get('close')  # 收盘价
                volume = item.get('volume', 0)  # 成交量
                
                if not date or not close:
                    continue
                
                # 检查是否为今天的数据，如果是，根据时间决定是否处理
                if date == today_str:
                    # 获取当前时间
                    now = datetime.now()
                    # 如果当前时间超过15:01，处理今天的数据作为收盘价
                    if now.hour > 15 or (now.hour == 15 and now.minute >= 1):
                        logger.info(f"处理今天({today_str})的收盘价数据")
                    else:
                        logger.info(f"跳过今天({today_str})的数据，由02模块处理")
                        continue
                
                # 跳过已经处理过的日期
                if date in date_set:
                    continue
                date_set.add(date)
                
                try:
                    close = float(close)  # 收盘价（历史数据）
                    volume = float(volume) # 成交量
                except ValueError:
                    continue
                
                lof_data.append({
                    '日期': date,
                    'LOF交易价格': close,  # 历史收盘价
                    '成交量': volume       # 历史成交量
                })
            
            if lof_data:
                # 转换为DataFrame
                df = pd.DataFrame(lof_data)
                # 按日期排序（降序）
                df['日期'] = pd.to_datetime(df['日期'], format='%Y-%m-%d')
                df = df.sort_values('日期', ascending=False)
                # 保留完整的日期格式，包含年份
                df['日期'] = df['日期'].dt.strftime('%Y-%m-%d')
                
                logger.info(f"成功获取LOF基金 {fund_code} 历史收盘价格数据，共{len(df)}条记录")
                return df
            else:
                logger.warning("新浪返回的数据为空")
                return None
        else:
            logger.error("新浪返回的数据格式不正确")
            return None

# ================= 测试入口 =================
if __name__ == "__main__":
    fetcher = DataFetcher()
    test_code = "162411"  # 华宝油气为例
    print("=== 测试获取价格 ===")
    price_df = fetcher.fetch_lof_price_data(test_code)
    if price_df is not None:
        print(price_df.head())
        
    print("\n=== 测试获取净值 ===")
    nav_dict = fetcher.fetch_lof_nav_data(test_code)
    if nav_dict:
        # 打印前5条净值数据
        for idx, (date, nav) in enumerate(nav_dict.items()):
            if idx >= 5: break
            print(f"日期: {date}, 净值: {nav}")
