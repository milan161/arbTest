import requests
import json
import time
from typing import Union, List, Dict, Any
from ._mytoken import ROT_TOKEN

def post_json_payload_to_telegram(
    data_payload: Union[Dict[str, Any], List[Any]], 
    bot_token: str, 
    timeout: int = 30
) -> Union[List[Any], Dict[str, Any], None]:
    """
    向Telegram风格的Webhook端点发送JSON数据，并返回解析后的响应数据。
    
    参数:
        data_payload: 要发送的Python字典或列表，例如 {"key": "value"}
        bot_token: 您的TG_TOKEN，用于替换URL中的占位符
        timeout: 请求超时时间（秒），默认30秒
        
    返回:
        成功时返回服务器响应解析后的Python对象（通常为列表或字典）
        失败时返回None，并打印错误信息
    """
    url = f"https://palmmicro.com/php/telegram.php?token={bot_token}"
    
    try:
        json_payload = json.dumps(data_payload, ensure_ascii=False)
        # print(f"发送的JSON数据: {json_payload}") # 可根据需要注释掉以减少日志干扰
    except TypeError as e:
        print(f"数据序列化失败: {e}，请检查data_payload是否包含不可序列化的对象")
        return None
    
    headers = {'Content-Type': 'application/json'}
    
    # 强制禁用系统层面的 VPN 代理，确保直连，防止 415/502 错误
    # 💡 优化：将 None 改为空字符串 ""，彻底阻断 requests 读取系统环境变量
    bypass_proxies = {
        "http": "",
        "https": "",
        "all": ""
    }
    
    try:
        response = requests.post(
            url, 
            data=json_payload.encode('utf-8'), # 显式编码为utf-8，增强兼容性
            headers=headers, 
            timeout=timeout,
            proxies=bypass_proxies             # 注入代理绕过配置
        )
        
        response.raise_for_status()
        
        received_data = response.json()
        
        # print(f"服务器返回的原始内容: {response.text}")
        
        if isinstance(received_data, list):
            pass # print("成功：服务器返回了一个JSON数组。")
        elif isinstance(received_data, dict):
            pass # print("注意：服务器返回了一个JSON对象（字典）。")
            
        return received_data
        
    except requests.exceptions.Timeout:
        print(f"请求超时（{timeout}秒），请检查网络或增加timeout参数")
        return None
    except requests.exceptions.HTTPError as e:
        print(f"HTTP错误: {e}，状态码: {response.status_code}")
        print(f"服务器响应内容: {response.text}")
        return None
    except requests.exceptions.RequestException as e:
        print(f"网络请求失败: {e}")
        return None
    except json.JSONDecodeError as e:
        print(f"解析服务器返回的JSON时出错: {e}")
        print(f"服务器返回的原始内容（非JSON）: {response.text}")
        return None


def FetchPalmmicroData(strSymbols: str):
    ar = {
        'update_id': 886050244,
        'message': {
            'message_id': 6620,
            'from': {
                'id': 992671436,
                'is_bot': False,
                'first_name': 'woody',
                'username': 'palmmicro',
                'language_code': 'zh-Hans'
            },
            'chat': {
                'id': 992671436,
                'first_name': 'woody',
                'username': 'palmmicro',
                'type': 'private'
            },
            'date': 0,
            'text': ''
        }
    }
    
    arMessage = ar['message']
    arMessage['date'] = int(time.time())
    arMessage['text'] = strSymbols
    
    result = post_json_payload_to_telegram(ar, ROT_TOKEN)
    
    if result is not None:
        if isinstance(result, dict):
            # 安全获取字典键值，防止因服务器返回结构变化导致 KeyError 崩溃
            text_response = result.get('text')
            if text_response:
                # 核心修复：防止 text_response 是字典时切片报错
                if isinstance(text_response, (dict, list)):
                    preview_str = json.dumps(text_response, ensure_ascii=False, indent=2)
                else:
                    preview_str = str(text_response)
                print(f"提取到的文本: {preview_str[:400]}...") # 增加预览长度以看到更多结构
        return result
    else:
        print("❌ FetchPalmmicroData 执行失败，请检查上方网络日志。")
        return None
