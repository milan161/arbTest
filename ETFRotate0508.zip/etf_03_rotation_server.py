# -*- coding: utf-8 -*-
# etf_03_rotation_server.py - 独立的 ETF 轮动套利展示中心

import os
import sys
import sqlite3
import pandas as pd
import requests
import time
import threading  
import atexit  
import logging  # 引入 logging 模块
from flask import Flask, render_template, jsonify
from datetime import datetime
import numpy as np

from core.db_manager import DatabaseManager
from core.fund_data_fetcher import DataFetcher

# ================= 0. 日志配置 =================
# 屏蔽 ibapi 底层繁琐的 INFO 日志（十六进制报文等），只显示 WARNING 和 ERROR
logging.getLogger('ibapi').setLevel(logging.WARNING)

# ================= 1. 初始化基础组件 =================
app = Flask(__name__)
db_manager = DatabaseManager()
cache_lock = threading.Lock()

# ================= 2. 盈透 (IB) 安全加载机制 =================
IB_AVAILABLE = False
ib_reader = None
try:
    from core.ib_reader import IBReader
    import random
    ib_reader = IBReader(client_id=random.randint(3000, 3999))
    IB_AVAILABLE = True
except Exception as e:
    print(f"⚠️ [行情降级] 无法加载盈透模块或环境未就绪。将完全使用新浪静态兜底数据运行！详细错误: {e}")

# ================= 3. 全局缓存与数据清理 =================
SINA_CACHE = {
    'last_update': 0,        
    'market_data': {},       
    'us_prices': {},         
    'rt_fx': 0.0             
}

def cleanup_ib_connection():
    """程序退出时自动调用的清理函数，优雅断开 IB 连接"""
    global ib_reader, IB_AVAILABLE
    if IB_AVAILABLE and ib_reader:
        print("\n🛑 [系统] 收到退出信号，正在断开 IB API 连接...")
        try:
            ib_reader.disconnect()
            print("✅ [系统] IB API 连接已成功断开，释放 Client ID。")
        except Exception as e:
            print(f"⚠️ [系统] 断开 IB 连接时发生异常: {e}")

atexit.register(cleanup_ib_connection)

# 统一列名处理函数
def normalize_etf_columns(df):
    col_map = {}
    if 'lof_code' not in df.columns and 'LOF基金代码' in df.columns: col_map['LOF基金代码'] = 'lof_code'
    if 'etf_code' not in df.columns and 'ETF基金代码' in df.columns: col_map['ETF基金代码'] = 'etf_code'
    if 'lof_name' not in df.columns and 'LOF基金名称' in df.columns: col_map['LOF基金名称'] = 'lof_name'
    if 'etf_name' not in df.columns and 'ETF基金名称' in df.columns: col_map['ETF基金名称'] = 'etf_name'
    if 'group_id' not in df.columns and '组别' in df.columns: col_map['组别'] = 'group_id'
    
    if col_map: df.rename(columns=col_map, inplace=True)
    return df


# ================= 4. Flask 路由定义 =================
@app.route('/')
def index():
    conn = db_manager._get_conn()
    try:
        df = pd.read_sql("SELECT * FROM etf_rotation_list", conn)
        df = normalize_etf_columns(df)
        if 'group_id' in df.columns: df = df.sort_values(by='group_id', ascending=True)
    except Exception as e:
        print(f"🔥 [错误] 读取数据库失败: {e}")
        df = pd.DataFrame()
    finally:
        conn.close()
    
    groups_data = {}
    for _, row in df.iterrows():
        gid_raw = row.get('group_id')
        gid = 99 if pd.isna(gid_raw) or str(gid_raw).strip() == '' or str(gid_raw).lower() == 'nan' else int(float(gid_raw))
            
        if gid not in groups_data: groups_data[gid] = []
            
        lof_code = str(row.get('lof_code', '')).split('.')[0].strip()
        etf_code = str(row.get('etf_code', '')).split('.')[0].strip()
            
        if lof_code and lof_code.lower() not in ['nan', 'none', ''] and not any(f['code'] == lof_code for f in groups_data[gid]):
            groups_data[gid].append({'group_id': gid, 'code': lof_code, 'name': str(row.get('lof_name', '')).strip(), 'type': 'LOF'})
            
        if etf_code and etf_code.lower() not in ['nan', 'none', ''] and not any(f['code'] == etf_code for f in groups_data[gid]):
            groups_data[gid].append({'group_id': gid, 'code': etf_code, 'name': str(row.get('etf_name', '')).strip(), 'type': 'ETF'})
            
    flat_data = []
    for gid in sorted(groups_data.keys()): flat_data.extend(groups_data[gid])
        
    return render_template('index.html', etf_data=flat_data)


@app.route('/api/history/<code>')
def get_history(code):
    """获取指定基金的历史数据，溢价率算法为：当日价格 / 前一日净值 - 1"""
    conn = db_manager._get_conn()
    try:
        query = "SELECT date, fund_code, price, nav FROM fund_data WHERE fund_code = ? ORDER BY date ASC"
        df = pd.read_sql(query, conn, params=(code,))
        
        need_update = False
        today_str = datetime.now().strftime('%Y-%m-%d')
        
        if df.empty:
            need_update = True
        else:
            latest_db_date = df['date'].max()
            if latest_db_date < today_str:
                need_update = True

        if need_update:
            try:
                fetcher = DataFetcher()
                price_df = fetcher.fetch_lof_price_data(code)
                nav_dict = fetcher.fetch_lof_nav_data(code)
                
                if price_df is not None and not price_df.empty:
                    df_crawled = price_df.copy()
                    df_crawled['nav'] = df_crawled['日期'].map(nav_dict)
                    df_crawled = df_crawled.rename(columns={'日期': 'date', 'LOF交易价格': 'price'})
                    df_crawled['fund_code'] = code
                    df_crawled['price'] = pd.to_numeric(df_crawled['price'], errors='coerce')
                    df_crawled['nav'] = pd.to_numeric(df_crawled['nav'], errors='coerce')
                    df_crawled = df_crawled[['date', 'fund_code', 'price', 'nav']]
                    
                    if not df.empty:
                        existing_dates = df['date'].tolist()
                        df_crawled = df_crawled[~df_crawled['date'].isin(existing_dates)]
                    
                    if not df_crawled.empty:
                        df_crawled.to_sql('fund_data', conn, if_exists='append', index=False)
                        
                    df = pd.read_sql(query, conn, params=(code,))
            except Exception as crawl_err:
                print(f"❌ 爬虫异常: {crawl_err}")

        if df.empty: return jsonify([])

        df = df.sort_values('date', ascending=True)
        df['price'] = pd.to_numeric(df['price'], errors='coerce')
        df['nav'] = pd.to_numeric(df['nav'], errors='coerce')
        df['nav'] = df['nav'].replace(0, np.nan)
        
        # 修正后的推演算法：当天价格 / 昨天净值
        df['premium'] = (df['price'] / df['nav'].shift(1) - 1) * 100
        df['change'] = (df['price'] / df['price'].shift(1) - 1) * 100
        
        df = df.sort_values(by='date', ascending=False).head(20).copy()
        
        df['premium'] = df['premium'].replace([np.inf, -np.inf], np.nan).round(2)
        df['change'] = df['change'].replace([np.inf, -np.inf], np.nan).round(2)
        df = df.fillna(0) 
        
        return jsonify(df.to_dict(orient='records'))
    except Exception as e:
        return jsonify([])
    finally:
        conn.close()


@app.route('/api/prices')
def get_prices():
    conn = db_manager._get_conn()
    df = pd.read_sql("SELECT * FROM etf_rotation_list", conn)
    df = normalize_etf_columns(df)
    
    codes = list(set([str(c).split('.')[0].strip() for c in df.get('lof_code', pd.Series()).tolist() + df.get('etf_code', pd.Series()).tolist() if pd.notna(c) and str(c).strip() != '']))
    
    group_us_map = {1: 'xop', 2: 'xbi', 3: 'spy', 4: 'qqq'}
    code_to_us = {}
    for _, row in df.iterrows():
        gid = row.get('group_id', 3)
        us_sym = group_us_map.get(gid, 'spy')
        if pd.notna(row.get('lof_code')): code_to_us[str(row['lof_code']).split('.')[0].strip()] = us_sym
        if pd.notna(row.get('etf_code')): code_to_us[str(row['etf_code']).split('.')[0].strip()] = us_sym
    
    current_time = time.time()
    if current_time - SINA_CACHE['last_update'] > 15:
        with cache_lock:
            if time.time() - SINA_CACHE['last_update'] > 15:
                sina_queries = []
                for code in codes:
                    sina_queries.append(f"sh{code}" if str(code).startswith('5') else f"sz{code}")
                sina_queries.extend(["gb_xop", "gb_xbi", "gb_spy", "gb_qqq", "fx_susdcny"])
                        
                url = f"http://hq.sinajs.cn/list={','.join(sina_queries)}"
                headers = {"Referer": "https://finance.sina.com.cn/"}
                
                try:
                    # 💡 禁用请求走 VPN 系统代理，强制直连避免被拉黑
                    bypass_proxies = {"http": None, "https": None}
                    resp = requests.get(url, headers=headers, timeout=5, proxies=bypass_proxies)
                    resp.encoding = 'gbk'
                    lines = resp.text.strip().split('\n')
                    
                    temp_market = {}
                    for line in lines:
                        if '="' not in line: continue
                        key = line.split('=')[0].replace('var hq_str_', '')
                        data_str = line.split('="')[1].rstrip('";')
                        if not data_str: continue
                        fields = data_str.split(',')
                        
                        if key.startswith('sh') or key.startswith('sz'):
                            c = key[2:]
                            if len(fields) >= 4:
                                pre_close, price = float(fields[2]), float(fields[3])
                                temp_market[c] = {'price': price if price > 0 else pre_close}
                        elif key.startswith('gb_'):
                            sym = key[3:]
                            if len(fields) >= 3:
                                SINA_CACHE['us_prices'][sym] = {'price': float(fields[1])}
                        elif key == 'fx_susdcny':
                            if len(fields) >= 2:
                                new_fx = float(fields[1])
                                if new_fx != SINA_CACHE['rt_fx'] and new_fx > 0:
                                    SINA_CACHE['rt_fx'] = new_fx
                                
                    SINA_CACHE['market_data'] = temp_market
                    SINA_CACHE['last_update'] = time.time()  
                except Exception as e:
                    print(f"⚠️ 新浪API数据获取失败, 使用上一秒缓存: {e}")

    market_data = {}
    for code in codes:
        market_data[code] = {'price': SINA_CACHE['market_data'].get(code, {}).get('price', 0.0)}
        
    us_prices = {}
    for sym in ['xop', 'xbi', 'spy', 'qqq']:
        ib_p = 0.0
        if IB_AVAILABLE and ib_reader:
            ib_p = ib_reader.prices.get(sym.upper(), {}).get('bid', 0.0)
        if ib_p > 0:
            us_prices[sym] = {'price': ib_p}
        else:
            us_prices[sym] = SINA_CACHE['us_prices'].get(sym, {'price': 0.0})
        
    rt_fx = SINA_CACHE['rt_fx']
    
    for code in codes:
        if code not in market_data: market_data[code] = {'price': 0.0}
            
        factor = db_manager.get_latest_fund_factor(code)
        base_nav = float(factor.get('nav', factor.get('netvalue', 0.0))) if factor else 0.0
        position = factor.get('position', 0.95) if factor else 0.95
        hedge = factor.get('hedge') if factor else None
        
        rt_val, rt_prem = 0.0, 0.0
        us_sym = code_to_us.get(code, 'spy')
        us_data = us_prices.get(us_sym)
        
        if base_nav > 0 and us_data and us_data['price'] > 0 and rt_fx > 0 and hedge:
            rt_val = base_nav * (1.0 - position) + (us_data['price'] * rt_fx) / hedge
            rt_price = market_data[code]['price']
            if rt_price > 0 and rt_val > 0:
                rt_prem = (rt_price - rt_val) / rt_val * 100.0
                
        market_data[code].update({'hedge': hedge, 'position': position, 'rt_val': rt_val, 'rt_prem': rt_prem})
            
    market_data['sys_meta'] = {
        'rt_fx': rt_fx,
        'update_time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    }

    conn.close()
    return jsonify(market_data)


# ================= 5. 启动程序的主入口 =================
if __name__ == '__main__':
    print("\n==================================================")
    print("🚀 启动独立轮动套利展示中心... (支持网页端访问)")
    print("==================================================\n")
    if IB_AVAILABLE and ib_reader:
        try:
            ib_reader.symbols = ['XOP', 'XBI', 'SPY', 'QQQ']
            ib_reader.start_polling()
        except Exception as e:
            print(f"⚠️ [行情降级] IB 启动轮询失败，无法连接到 TWS: {e}")
    
    app.run(host='0.0.0.0', port=5005, debug=False)
