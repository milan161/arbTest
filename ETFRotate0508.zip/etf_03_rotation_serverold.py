# -*- coding: utf-8 -*-
# etf_002_rotation_server.py - 独立的 ETF 轮动套利展示中心

import os
import sys
import sqlite3
import pandas as pd
import requests
import time
from flask import Flask, render_template_string, jsonify

from core.db_manager import DatabaseManager

app = Flask(__name__)
db_manager = DatabaseManager()

# ================= 盈透 (IB) 安全加载机制 =================
IB_AVAILABLE = False
ib_reader = None
try:
    from core.ib_reader import IBReader
    import random
    ib_reader = IBReader(client_id=random.randint(3000, 3999))
    IB_AVAILABLE = True
except Exception as e:
    print(f"⚠️ [行情降级] 无法加载盈透模块或环境未就绪。将完全使用新浪静态兜底数据运行！详细错误: {e}")

# ================= 全局缓存机制 (防新浪封禁) =================
SINA_CACHE = {
    'last_update': 0,        # 上次访问新浪的时间戳
    'market_data': {},       # A股兜底价格
    'us_prices': {},         # 美股标的价格
    'rt_fx': 0.0             # 实时汇率 (初始为0，强制等待新浪API实时获取)
}

# =====================================================================
# 前端精美交互 UI 模板 (基于你的上下分层、TAB 切换、买卖提权需求)
# =====================================================================
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>ETF轮动套利监控中心 (独立测试版)</title>
    <style>
        :root {
            --bg-color: #f1f5f9; --card-bg: #ffffff;
            --primary: #2563eb; --primary-hover: #1d4ed8;
            --danger: #dc2626; --danger-hover: #b91c1c;
            --success: #16a34a; --success-hover: #15803d;
            --border: #e2e8f0; --text-main: #1e293b; --text-muted: #64748b;
            --font-sys: -apple-system, "Microsoft YaHei", sans-serif;
        }
        body { font-family: var(--font-sys); background-color: var(--bg-color); color: var(--text-main); margin: 0; padding: 20px; font-size: 14px; }
        .container { max-width: 1400px; margin: 0 auto; display: flex; flex-direction: column; gap: 20px; }
        
        /* 顶部看板区域 (选中的卖出标的) */
        .top-panel { background: #fff5f5; border: 2px solid #fecaca; border-radius: 10px; padding: 20px; box-shadow: 0 4px 6px -1px rgba(220,38,38,0.1); min-height: 80px; display: flex; flex-direction: column; justify-content: center; transition: all 0.3s ease; }
        .top-panel.empty { background: var(--card-bg); border: 2px dashed #cbd5e1; align-items: center; color: var(--text-muted); box-shadow: none; }
        
        /* 底部列表区域 */
        .bottom-panel { background: var(--card-bg); border-radius: 10px; border: 1px solid var(--border); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); overflow: hidden; }
        
        /* TAB 控制区 */
        .tabs { display: flex; background: #f8fafc; border-bottom: 1px solid var(--border); }
        .tab-btn { padding: 15px 30px; border: none; background: none; font-size: 15px; font-weight: bold; color: var(--text-muted); cursor: pointer; transition: 0.2s; border-bottom: 3px solid transparent; }
        .tab-btn:hover { background: #f1f5f9; color: var(--primary); }
        .tab-btn.active { color: var(--primary); border-bottom-color: var(--primary); background: #fff; }
        
        /* 表格样式 */
        .tab-content { display: none; padding: 0; }
        .tab-content.active { display: block; animation: fadeIn 0.3s; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f8fafc; padding: 12px; text-align: center; color: var(--text-muted); border-bottom: 2px solid var(--border); font-size: 13px; }
        td { padding: 12px; text-align: center; border-bottom: 1px solid var(--border); }
        tr:hover td { background: #f0f7ff; }
        
        .mono { font-family: 'Consolas', monospace; font-weight: 600; font-size: 15px;}
        
        /* 按钮与交互标签 */
        .select-btn { padding: 6px 12px; border-radius: 6px; border: 1px solid #ccc; cursor: pointer; font-weight: bold; background: #fff; transition: 0.2s; }
        .btn-buy { color: var(--success); border-color: var(--success); }
        .btn-buy:hover { background: var(--success); color: white; }
        .btn-sell-outline { color: var(--danger); border-color: var(--danger); }
        .btn-sell-outline:hover { background: var(--danger); color: white; }
        
        .action-btn { padding: 8px 24px; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 15px; border: none; color: white; transition: 0.2s; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .bg-danger { background: var(--danger); }
        .bg-danger:hover { background: var(--danger-hover); transform: translateY(-1px); }
        .bg-success { background: var(--success); }
        .bg-success:hover { background: var(--success-hover); transform: translateY(-1px); }
        
        .flex-row { display: flex; align-items: center; gap: 15px; }
        .highlight-text { font-size: 20px; font-weight: bold; color: var(--danger); }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    </style>
</head>
<body>
    <div class="container">
        <div style="display:flex; justify-content:space-between; align-items:center;">
            <div style="display:flex; align-items:center; gap: 15px;">
                <h2 style="margin:0; color: var(--text-main);">🔄 ETF 轮动套利中心</h2>
                <div style="font-size: 14px; background: #e0f2fe; padding: 5px 12px; border-radius: 6px; border: 1px solid #bae6fd;">
                    💱 实时汇率: <span id="sys-fx" style="color: #0369a1; font-weight: bold; font-family: monospace; font-size: 15px;">获取中...</span>
                </div>
                <div style="font-size: 14px; background: #f1f5f9; padding: 5px 12px; border-radius: 6px; border: 1px solid #e2e8f0; color: var(--text-muted);">
                    🕒 <span id="sys-time" style="font-family: monospace; font-weight: bold;">----/--/-- --:--:--</span>
                </div>
            </div>
            <div style="background: white; padding: 8px 15px; border-radius: 8px; border: 1px solid var(--border); box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                <label style="font-weight: bold; color: var(--text-muted); margin-right: 10px;">套利计划本金 (元):</label>
                <input type="number" id="capital-input" value="100000" step="10000" style="padding: 5px; width: 120px; border: 1px solid #ccc; border-radius: 4px; font-weight: bold; color: var(--primary); font-size: 14px;">
            </div>
        </div>
                
        <!-- 上半部分：主炮管 (目标卖出基金) -->
        <div id="target-panel" class="top-panel empty">
            <div id="target-empty-text">👇 请在下方列表中，选择并将高溢价基金切换为【设为卖出】</div>
            
            <div id="target-content" style="display: none; justify-content: space-between; align-items: center;">
                <div class="flex-row">
                    <div style="background: white; border: 1px solid #fecaca; padding: 10px 20px; border-radius: 8px;">
                        <div style="color: #ef4444; font-size: 12px; font-weight: bold; margin-bottom: 4px;">锁定卖出目标</div>
                        <div class="highlight-text" id="t-name">-</div>
                        <div class="mono" style="color: var(--text-muted);" id="t-code">-</div>
                    </div>
                    
                    <div style="display: flex; gap: 30px; margin-left: 20px;">
                        <div>
                            <div style="font-size: 12px; color: var(--text-muted);">盘口实时价</div>
                            <div class="mono" style="font-size: 18px;" id="t-price">-</div>
                        </div>
                        <div>
                            <div style="font-size: 12px; color: var(--text-muted);">建议卖出数量</div>
                            <div class="mono" style="font-size: 18px; color: var(--primary);" id="t-vol">-</div>
                        </div>
                        <div>
                            <div style="font-size: 12px; color: var(--text-muted);">实时溢价率</div>
                            <div class="mono" style="font-size: 18px; color: var(--danger);" id="t-prem">-</div>
                        </div>
                    </div>
                </div>
                
                <button class="action-btn bg-danger" onclick="executeTargetTrade('SELL')">🚀 确认卖出 (模拟)</button>
            </div>
        </div>
        
        <!-- 下半部分：各组子基金弹药库 -->
        <div class="bottom-panel">
            <div class="tabs" id="group-tabs">
                <!-- 由 JS 动态生成 Tabs -->
            </div>
            
            <div id="table-container">
                <!-- 由 JS 动态生成 表格内容 -->
                <h3 style="color:#f59e0b; text-align:center; padding:50px;" id="loading-status">
                    ⏳ 正在加载组件，请稍候...<br><br>
                    <span style="font-size: 14px; color: #64748b;">(如果一直卡在这里，请确认：1. 已运行01/02建立数据；2. 务必使用 Chrome 或 Edge 浏览器)</span>
                </h3>
            </div>
        </div>
    </div>

    <script>
        // 从后端注入初始化的数据库 ETF 列表
        let etfData = {{ etf_data | tojson | safe }};
        
        // 组别名称映射表
        const groupNames = {
            1: "油气",
            2: "生物科技",
            3: "标普500",
            4: "纳指100"
        };
        
        // 按组别记录当前锁定的目标：{ groupId: {code, name} }
        let selectedTargets = {};
        let currentGroupId = null;
        
        function initPage() {
            try {
                if (!etfData || etfData.length === 0) {
                    document.getElementById('table-container').innerHTML = '<h3 style="color:red; text-align:center; padding:50px;">❌ 数据库未获取到有效配置！<br><br>请确保已成功运行 01 初始化程序。</h3>';
                    return;
                }
                
                // 1. 获取所有不重复的组别
                let groups = [...new Set(etfData.map(item => item.group_id))].sort((a, b) => a - b);
                if (groups.length > 0) currentGroupId = groups[0];
                
                let tabsHtml = '';
                let contentsHtml = '';
                
                groups.forEach((groupId, index) => {
                    // 生成 Tab 头 (使用名称映射)
                    let activeCls = index === 0 ? 'active' : '';
                    let tabName = groupNames[groupId] || `第 ${groupId} 组`;
                    tabsHtml += `<button class="tab-btn ${activeCls}" onclick="switchTab(${groupId})" data-target="tab-${groupId}">${tabName}</button>`;
                    
                    // 过滤当前组的数据
                    let groupFunds = etfData.filter(item => item.group_id === groupId);
                    
                    // 生成该组的 Table
                    let trs = '';
                    groupFunds.forEach(fund => {
                        let typeLabel = fund.type === 'LOF' ? 
                            '<span style="font-size:11px;color:#fff;background:#2563eb;padding:2px 5px;border-radius:3px;margin-right:5px;">LOF基准</span>' : 
                            '<span style="font-size:11px;color:#fff;background:#8b5cf6;padding:2px 5px;border-radius:3px;margin-right:5px;">ETF目标</span>';
                        
                        trs += `
                            <tr id="row-${fund.code}">
                                <td class="mono">${fund.code}</td>
                                <td style="font-weight: bold; text-align: left;">${typeLabel}${fund.name}</td>
                                <td class="mono" style="color: var(--primary); font-weight:bold;" id="price-${fund.code}">-.---</td>
                                <td class="mono" style="color: #8b5cf6;" id="qty-${fund.code}">计算中</td>
                                <td class="mono" style="color: #64748b;" id="hedge-${fund.code}">计算中</td>
                                <td class="mono" style="background: #fffbeb;" id="val-${fund.code}">计算中</td>
                                <td class="mono" style="color: var(--text-muted); font-weight:bold;" id="prem-${fund.code}">计算中</td>
                                <td>
                                    <div style="display:flex; justify-content:center; gap:8px; align-items:center;">
                                        <button class="select-btn btn-buy" onclick="quickBuy('${fund.code}')">直接买入</button>
                                        <span style="color:#cbd5e1;">|</span>
                                        <button class="select-btn btn-sell-outline" id="btn-toggle-${fund.code}" onclick="setAsTarget('${fund.code}', '${fund.name}', ${groupId})">设为卖出</button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    });
                    
                    let displayStyle = index === 0 ? 'block' : 'none';
                    contentsHtml += `
                        <div id="tab-${groupId}" class="tab-content" style="display: ${displayStyle};">
                            <table>
                                <thead>
                                    <tr>
                                        <th width="10%">基金代码</th>
                                        <th width="15%">基金简称</th>
                                        <th width="12%">盘口价格</th>
                                        <th width="12%">建议数量</th>
                                        <th width="12%">对冲值</th>
                                        <th width="12%" style="background:#fef3c7;">实时估值</th>
                                        <th width="12%">实时溢价</th>
                                        <th width="15%">操作</th>
                                    </tr>
                                </thead>
                                <tbody>${trs}</tbody>
                            </table>
                        </div>
                    `;
                });
                
                document.getElementById('group-tabs').innerHTML = tabsHtml;
                document.getElementById('table-container').innerHTML = contentsHtml;
            } catch (err) {
                document.getElementById('table-container').innerHTML = `<h3 style="color:red; text-align:center; padding:50px;">❌ 页面渲染出错: ${err.message}</h3>`;
            }
        }
        
        function switchTab(groupId) {
            currentGroupId = groupId;
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            let targetBtn = document.querySelector(`.tab-btn[data-target="tab-${groupId}"]`);
            if(targetBtn) targetBtn.classList.add('active');
            
            document.querySelectorAll('.tab-content').forEach(content => {
                content.style.display = 'none';
                content.classList.remove('active');
            });
            
            let target = document.getElementById(`tab-${groupId}`);
            if(target) {
                target.style.display = 'block';
                target.classList.add('active');
            }
            
            // 切换 Tab 时，同步切换上方的目标面板状态
            if (selectedTargets[groupId]) {
                let t = selectedTargets[groupId];
                updateTargetPanel(t.code, t.name);
            } else {
                clearTargetPanel();
            }
        }
        
        async function quickBuy(code) {
            alert(`📢 监控版提示：\\n无法直接买入 [${code}]。请前往交易软件手动操作。`);
        }
        
        function setAsTarget(code, name, groupId) {
            selectedTargets[groupId] = {code: code, name: name};
            
            // 恢复该组内所有按钮的默认状态
            document.querySelectorAll(`#tab-${groupId} .btn-sell-outline`).forEach(btn => {
                btn.textContent = '设为卖出';
                btn.style.background = '#fff';
                btn.style.color = 'var(--danger)';
            });
            
            // 赋予新目标高亮状态
            let currentBtn = document.getElementById(`btn-toggle-${code}`);
            if(currentBtn) {
                currentBtn.textContent = '已锁定卖出';
                currentBtn.style.background = 'var(--danger)';
                currentBtn.style.color = '#fff';
            }
            
            // 如果当前正好在这个 Tab，刷新上方看板
            if (currentGroupId === groupId) {
                updateTargetPanel(code, name);
            }
        }
        
        function updateTargetPanel(code, name) {
            // 更新顶部面板信息
            document.getElementById('t-code').textContent = code;
            document.getElementById('t-name').textContent = name;
            let pEl = document.getElementById(`price-${code}`);
            document.getElementById('t-price').textContent = pEl ? pEl.textContent : '-';
            let qEl = document.getElementById(`qty-${code}`);
            document.getElementById('t-vol').textContent = qEl && qEl.textContent !== '计算中' ? qEl.textContent : '等待中';
            let prEl = document.getElementById(`prem-${code}`);
            document.getElementById('t-prem').textContent = prEl ? prEl.textContent : '-';
            
            document.getElementById('target-panel').classList.remove('empty');
            document.getElementById('target-empty-text').style.display = 'none';
            document.getElementById('target-content').style.display = 'flex';
        }
        
        function clearTargetPanel() {
            document.getElementById('target-panel').classList.add('empty');
            document.getElementById('target-empty-text').style.display = 'block';
            document.getElementById('target-content').style.display = 'none';
        }
        
        async function executeTargetTrade(action) {
            let target = selectedTargets[currentGroupId];
            if(!target) return;
            
            alert(`📢 监控版提示：\\n请前往交易软件卖出目标 [${target.code}]。`);
        }
        
        // ================= AJAX 异步拉取真实盘口数据 =================
        async function fetchRealtimePrices() {
            try {
                let res = await fetch('/api/prices');
                let prices = await res.json();
                
                // 更新系统元数据 (汇率与刷新时间)
                if (prices.sys_meta) {
                    document.getElementById('sys-fx').textContent = prices.sys_meta.rt_fx > 0 ? prices.sys_meta.rt_fx.toFixed(4) : "获取中...";
                    document.getElementById('sys-time').textContent = prices.sys_meta.update_time;
                }

                for(let code in prices) {
                    if (code === 'sys_meta') continue; // 跳过元数据不渲染表格
                    let item = prices[code];
                    let pEl = document.getElementById(`price-${code}`);
                    if(pEl && item.price > 0) pEl.textContent = item.price.toFixed(3);
                    
                    let hEl = document.getElementById(`hedge-${code}`);
                    if(hEl) hEl.textContent = item.hedge ? item.hedge.toFixed(4) : "未提取";
                    
                    let vEl = document.getElementById(`val-${code}`);
                    if(vEl) { vEl.textContent = item.rt_val > 0 ? item.rt_val.toFixed(4) : "无基准"; vEl.style.color = "#b45309"; vEl.style.fontWeight = "bold"; }
                    
                    let prEl = document.getElementById(`prem-${code}`);
                    if(prEl && item.rt_prem !== 0) {
                        prEl.textContent = (item.rt_prem > 0 ? '+' : '') + item.rt_prem.toFixed(2) + '%';
                        prEl.style.color = item.rt_prem > 0 ? '#dc2626' : '#16a34a';
                    }
                    
                    // ================= 核心推演：双轨数量算法 =================
                    let qEl = document.getElementById(`qty-${code}`);
                    if(qEl && item.price > 0 && item.hedge) {
                        let currentCapital = parseFloat(document.getElementById('capital-input').value) || 100000;
                        let tempQty = currentCapital / item.price;
                        let usHedge = Math.round(tempQty / item.hedge);
                        let finalQty = Math.round((usHedge * item.hedge) / 100) * 100;
                        qEl.textContent = finalQty < 100 ? 100 : finalQty; // A股保底 100 股
                    }
                }
                
                // 同步刷新上方目标面板的现价
                if (currentGroupId && selectedTargets[currentGroupId]) {
                    let t = selectedTargets[currentGroupId];
                    if (prices[t.code] && document.getElementById('t-code').textContent === t.code) {
                        document.getElementById('t-price').textContent = prices[t.code].price.toFixed(3);
                        // 联动更新上方炮管的执行数量
                        let qEl = document.getElementById(`qty-${t.code}`);
                        if(qEl) document.getElementById('t-vol').textContent = qEl.textContent;
                    }
                }
            } catch (err) {
                console.error("获取实时价格失败:", err);
            }
        }
        
        window.onload = () => { initPage(); fetchRealtimePrices(); setInterval(fetchRealtimePrices, 3000); };
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    # 从刚刚通过 001 同步好的库里，读取分组配置
    conn = db_manager._get_conn()
    try:
        # 必须直接全表扫描，千万不要先查特定列！否则一旦有列名不匹配，就会抛错跳过，导致数据变空
        df = pd.read_sql("SELECT * FROM etf_rotation_list", conn)
        
        # 智能动态映射列名
        col_map = {}
        if 'lof_code' not in df.columns and 'LOF基金代码' in df.columns: col_map['LOF基金代码'] = 'lof_code'
        if 'etf_code' not in df.columns and 'ETF基金代码' in df.columns: col_map['ETF基金代码'] = 'etf_code'
        if 'lof_name' not in df.columns and 'LOF基金名称' in df.columns: col_map['LOF基金名称'] = 'lof_name'
        if 'etf_name' not in df.columns and 'ETF基金名称' in df.columns: col_map['ETF基金名称'] = 'etf_name'
        if 'group_id' not in df.columns and '组别' in df.columns: col_map['组别'] = 'group_id'
        
        if col_map: df.rename(columns=col_map, inplace=True)
        
        if 'group_id' in df.columns:
            df = df.sort_values(by='group_id', ascending=True)
    except Exception as e:
        print(f"🔥 [错误] 读取数据库失败: {e}")
        df = pd.DataFrame()
    conn.close()
    
    print(f"📊 [诊断] 从数据库成功读取到 {len(df)} 行基金配置。")
    
    # 拍平结构：把每个组别对应的 LOF 和 ETF 全部提取成同级并列关系，打上 type 标签以供区分
    groups_data = {}
    for _, row in df.iterrows():
        gid_raw = row.get('group_id')
        if pd.isna(gid_raw) or str(gid_raw).strip() == '' or str(gid_raw).lower() == 'nan':
            gid = 99 # 如果组别为空，强行塞进99组
        else:
            gid = int(float(gid_raw))
            
        if gid not in groups_data:
            groups_data[gid] = []
            
        lof_code = str(row.get('lof_code', '')).split('.')[0].strip()
        etf_code = str(row.get('etf_code', '')).split('.')[0].strip()
            
        # 提取当前行的 LOF 基准 (如果本组还没加过的话)
        if lof_code and lof_code.lower() not in ['nan', 'none', ''] and not any(f['code'] == lof_code for f in groups_data[gid]):
            groups_data[gid].append({
                'group_id': gid, 'code': lof_code, 'name': str(row.get('lof_name', '')).strip(), 'type': 'LOF'
            })
            
        # 提取当前行的 ETF 目标
        if etf_code and etf_code.lower() not in ['nan', 'none', ''] and not any(f['code'] == etf_code for f in groups_data[gid]):
            groups_data[gid].append({
                'group_id': gid, 'code': etf_code, 'name': str(row.get('etf_name', '')).strip(), 'type': 'ETF'
            })
            
    # 组合为前端一维列表
    flat_data = []
    for gid in sorted(groups_data.keys()):
        flat_data.extend(groups_data[gid])
        
    print(f"📊 [诊断] 拍平并清洗后，传给网页的有效基金标的共 {len(flat_data)} 个。")
    return render_template_string(HTML_TEMPLATE, etf_data=flat_data)

@app.route('/api/prices')
def get_prices():
    """
    AJAX 接口：获取监控池中所有基金的实时盘口价格
    数据源：纯新浪接口
    """
    conn = db_manager._get_conn()
    
    # 全表扫描，避免遗漏 group_id 导致 KeyError
    df = pd.read_sql("SELECT * FROM etf_rotation_list", conn)
    
    # 智能兼容列名，防崩溃
    col_map = {}
    if 'lof_code' not in df.columns and 'LOF基金代码' in df.columns: col_map['LOF基金代码'] = 'lof_code'
    if 'etf_code' not in df.columns and 'ETF基金代码' in df.columns: col_map['ETF基金代码'] = 'etf_code'
    if 'group_id' not in df.columns and '组别' in df.columns: col_map['组别'] = 'group_id'
    if col_map: df.rename(columns=col_map, inplace=True)
    
    # 提取所有去重的基金代码
    codes = list(set([str(c).split('.')[0].strip() for c in df.get('lof_code', pd.Series()).tolist() + df.get('etf_code', pd.Series()).tolist() if pd.notna(c) and str(c).strip() != '']))
    
    # 1. 构建底层映射 (决定用哪个美股 ETF 来推演)
    group_us_map = {1: 'xop', 2: 'xbi', 3: 'spy', 4: 'qqq'}
    code_to_us = {}
    for _, row in df.iterrows():
        gid = row.get('group_id', 3)
        us_sym = group_us_map.get(gid, 'spy')
        if pd.notna(row.get('lof_code')): code_to_us[str(row['lof_code']).split('.')[0].strip()] = us_sym
        if pd.notna(row.get('etf_code')): code_to_us[str(row['etf_code']).split('.')[0].strip()] = us_sym
    
    # 2. 新浪宏观数据 15秒缓存阻断机制
    current_time = time.time()
    if current_time - SINA_CACHE['last_update'] > 15:
        sina_queries = []
        for code in codes:
            sina_queries.append(f"sh{code}" if str(code).startswith('5') else f"sz{code}")
        sina_queries.extend(["gb_xop", "gb_xbi", "gb_spy", "gb_qqq", "fx_susdcny"])
                
        url = f"http://hq.sinajs.cn/list={','.join(sina_queries)}"
        headers = {"Referer": "https://finance.sina.com.cn/"}
        
        try:
            resp = requests.get(url, headers=headers, timeout=5)
            resp.encoding = 'gbk'
            lines = resp.text.strip().split('\n')
            
            temp_market = {}
            for line in lines:
                if '="' not in line: continue
                key = line.split('=')[0].replace('var hq_str_', '')
                data_str = line.split('="')[1].rstrip('";')
                if not data_str: continue
                fields = data_str.split(',')
                
                if key.startswith('sh') or key.startswith('sz'):
                    c = key[2:]
                    if len(fields) >= 4:
                        pre_close, price = float(fields[2]), float(fields[3])
                        temp_market[c] = {'price': price if price > 0 else pre_close}
                elif key.startswith('gb_'):
                    sym = key[3:]
                    if len(fields) >= 3:
                        SINA_CACHE['us_prices'][sym] = {'price': float(fields[1])}
                elif key == 'fx_susdcny':
                    if len(fields) >= 2:
                        new_fx = float(fields[1])
                        if new_fx != SINA_CACHE['rt_fx'] and new_fx > 0:
                            print(f"💱 [新浪行情] 实时人民币汇率更新: {new_fx}")
                        SINA_CACHE['rt_fx'] = new_fx
                        
            SINA_CACHE['market_data'] = temp_market
            SINA_CACHE['last_update'] = current_time
        except Exception as e:
            print(f"⚠️ 新浪API数据获取失败, 使用上一秒缓存: {e}")

    # 3. 数据合并
    market_data = {}
    for code in codes:
        market_data[code] = {'price': SINA_CACHE['market_data'].get(code, {}).get('price', 0.0)}
        
    us_prices = {}
    for sym in ['xop', 'xbi', 'spy', 'qqq']:
        # 优先从 IB 获取美股夜盘/盘前买一价 (IB 需全大写)
        ib_p = 0.0
        if IB_AVAILABLE and ib_reader:
            ib_p = ib_reader.prices.get(sym.upper(), {}).get('bid', 0.0)
        if ib_p > 0:
            us_prices[sym] = {'price': ib_p}
        else:
            us_prices[sym] = SINA_CACHE['us_prices'].get(sym, {'price': 0.0})
        
    rt_fx = SINA_CACHE['rt_fx']

    # 4. 从全局基座提取常量因子进行数学魔法推演
    cursor = conn.cursor()
    
    for code in codes:
        if code not in market_data:
            market_data[code] = {'price': 0.0}
            
        factor = db_manager.get_latest_fund_factor(code)
        
        # 直接从 Woody 因子 (02程序拉取) 中提取最新的 T-1 基准净值
        base_nav = float(factor.get('nav', factor.get('netvalue', 0.0))) if factor else 0.0
        position = factor.get('position', 0.95) if factor else 0.95
        hedge = factor.get('hedge') if factor else None
        
        rt_val = 0.0
        rt_prem = 0.0
        
        us_sym = code_to_us.get(code, 'spy')
        us_data = us_prices.get(us_sym)
        
        # ======= 终极实时估值引擎 (常量折叠数学魔法) =======
        if base_nav > 0 and us_data and us_data['price'] > 0 and rt_fx > 0 and hedge:
            us_price = us_data['price']
            
            # Woody 终极化简公式：实时估值 = 基准净值 × (1 - 仓位) + (实时ETF × 实时汇率) / Hedge
            rt_val = base_nav * (1.0 - position) + (us_price * rt_fx) / hedge

            rt_price = market_data[code]['price']
            if rt_price > 0 and rt_val > 0:
                rt_prem = (rt_price - rt_val) / rt_val * 100.0
                
        market_data[code]['hedge'] = hedge
        market_data[code]['position'] = position
        market_data[code]['rt_val'] = rt_val
        market_data[code]['rt_prem'] = rt_prem
            
    # 将全局宏观参数与时间戳打包，供前端看板展示
    market_data['sys_meta'] = {
        'rt_fx': rt_fx,
        'update_time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    }

    conn.close()
    return jsonify(market_data)

if __name__ == '__main__':
    print("🚀 启动独立轮动套利展示中心...")
    # 启动 IB 异步轮询获取美股实时价格
    if IB_AVAILABLE and ib_reader:
        try:
            ib_reader.symbols = ['XOP', 'XBI', 'SPY', 'QQQ']
            ib_reader.start_polling()
        except Exception as e:
            print(f"⚠️ [行情降级] IB 启动轮询失败，无法连接到 TWS: {e}")
    
    app.run(host='0.0.0.0', port=5005, debug=False)