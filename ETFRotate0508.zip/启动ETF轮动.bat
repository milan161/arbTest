@echo off
chcp 65001 >nul
title ETF轮动套利监控系统
color 0A

echo ==================================================
echo      🚀 启动 ETF 轮动套利监控系统 (一键启动)
echo ==================================================

:: 自动切换到脚本所在当前目录 (绿色版模式)
cd /d "%~dp0"

echo.
echo [1/3] 执行每日数据与监控池初始化...
python etf_01_data_init.py

echo.
echo [2/3] 提取 Woody 官方对冲核心因子...
python etf_02_woody_api.py

echo.
echo [3/3] 启动轮动监控面板...
start /b cmd /c "ping 127.0.0.1 -n 3 >nul && start http://localhost:5005/"

:: 启动主服务并挂起
python etf_03_rotation_server.py

pause
